Called Noisette using template code - able to do it on my iPhone
Is there a way to set up a test that doesn't have me calling real businesses?

I tested the error message by malforming the scheme
ttttelprompt:+15416545257 can open is false

