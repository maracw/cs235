const imageIndex = {

    'Dracula-top': require('../images/Dracula-1.png'),

    'Dracula-middle': require('../images/Dracula-2.png'),

    'Dracula-bottom': require('../images/Dracula-3.png'),

    'Unicorn-top': require('../images/Unicorn-1.png'),

    'Unicorn-middle': require('../images/Unicorn-2.png'),

    'Unicorn-bottom': require('../images/Unicorn-3.png'),

    'Merperson-top': require('../images/Mer-1.png'),

    'Merperson-middle': require('../images/Mer-2.png'),

    'Merperson-bottom': require('../images/Mer-3.png'),

    'Yeti-top': require('../images/Yeti-1.png'),
    'Yeti-middle': require('../images/Yeti-2.png'),
    'Yeti-bottom': require('../images/Yeti-3.png'),

    };
    
    export default imageIndex;